// Procura uma aba do dash ja aberta; se achar, troca ela para o lead e traz para frente.
// Se nao achar, abre uma aba nova. (Roda em segundo plano, só quando o botão pede.)
chrome.runtime.onMessage.addListener(function (msg) {
  if (!msg || msg.acao !== 'abrirDash' || !msg.url) return;
  chrome.tabs.query({ url: 'https://promovteam.github.io/dash-site/*' }, function (abas) {
    if (abas && abas.length) {
      var aba = abas[0];
      chrome.tabs.update(aba.id, { url: msg.url, active: true });
      if (aba.windowId !== undefined) chrome.windows.update(aba.windowId, { focused: true });
    } else {
      chrome.tabs.create({ url: msg.url });
    }
  });
});
