// ===== Promov · Dash na Clint (extensão) v2.7 — 10/09/2026 =====
// v2.7 (Bruno: "puxe o caso da pessoa pelo número ou pelos dados que ela preencheu como lead para já conseguir marcar"):
//   o clique manda para o dash TUDO que se souber da pessoa (telefone, nome, e-mail, Instagram — do cadastro da Clint
//   quando o robô responde, senão da tela) e o dash acha o lead por qualquer um desses dados e abre já marcando.
// v2.6 (Bruno: "como tem integração com a Clint, imagino ter alguma maneira"): a extensão captura o id do chat/contato
//   que a própria Clint usa nos pedidos internos (PerformanceObserver, sem mexer na página) e pergunta ao robô, que
//   devolve o cadastro pela API da Clint (nome, telefone, e-mail, Instagram, etapa, dono). A leitura da tela vira reserva.
// v2.5 (Bruno 10/09/2026: "por que a extensão não puxa o nome? e nem todas puxam?"): o nome vem também do cabeçalho
//   da conversa e do campo "Nome" do contato (antes só de perto do telefone, que fica no painel recolhido); contato sem
//   telefone na tela (Instagram) ganha cartão com o nome e um botão que procura a pessoa no dash pelo nome (#buscar=).
// v2.4 (Bruno 09/09/2026: "essa extensão poderia ser mais rápida"): o dash já começa a carregar escondido assim que
//   a Clint abre (clicar só mostra); o cartão do lead aparece na hora com o nome da tela e completa depois (planilha e
//   robô em paralelo, planilha pré-carregada); endereço do robô lido de robo.txt (poucos bytes) em vez do dash inteiro;
//   varredura da tela numa passada só, a cada 2 s, e parada quando a aba está escondida.
// v2.3 (Bruno 08/09/2026): o botão 📊 Dash abre DIRETO no "marcar reunião" para a pessoa da conversa
//   aberta (lê telefone E nome da tela da Clint); janela com bordas e cantos para redimensionar e
//   barra de cima para arrastar; botões A− / A+ para o tamanho do conteúdo; a versão aparece no topo.
// v2.1: janela móvel e redimensionável, botões início/agenda, funciona em app.clint.digital e app.useclint.com
// O conteúdo é sempre o dash publicado (?v=agora): atualizou o dash, atualizou aqui.
// Ordem de procura do telefone: 1) texto selecionado; 2) campo "Telefone/WhatsApp" do painel de
// contato; 3) telefones visíveis na tela, preferindo o do cabeçalho da conversa; se ficar em
// dúvida, mostra os candidatos e deixa colar o número.
(function () {
  if (document.getElementById('promov-agenda-btn')) return;

  var VERSAO_EXT = '2.7';
  var DASH = 'https://promovteam.github.io/dash-site/';
  var NOSSOS = '#promov-agenda-painel,#promov-lead-card,#promov-marcar-menu,#promov-agenda-btn';
  // versão publicada do dash: o HTML (1 MB) fica em cache por versão; sem ela, usa a hora (sem cache)
  var DASH_V = '';
  try { fetch(DASH + 'versao.txt?t=' + Date.now()).then(function (r) { return r.text(); }).then(function (t) { if (/^\d{4}-\d{2}-\d{2}/.test(t.trim())) DASH_V = t.trim(); }).catch(function () {}); } catch (e) {}
  function dashUrl(hash) { return DASH + '?v=' + (DASH_V || Date.now()) + hash; }

  function digitos(s) {
    var d = String(s || '').replace(/\D/g, '');
    if (d.indexOf('55') === 0 && d.length >= 12) d = d.slice(2);   // tira o +55
    return d;
  }
  function telValido(d) { return d.length === 10 || d.length === 11; }
  function bonito(d) {
    if (!telValido(d)) return d;
    return '(' + d.slice(0, 2) + ') ' + d.slice(2, d.length - 4) + '-' + d.slice(-4);
  }
  function guardar(chave, v) { try { localStorage.setItem(chave, JSON.stringify(v)); } catch (e) {} }
  function lembrar(chave) { try { return JSON.parse(localStorage.getItem(chave) || 'null'); } catch (e) { return null; } }

  // ===== arrasta um elemento pela alça e lembra onde ficou (clique curto continua sendo clique) =====
  function arrastavel(el, alca, chave) {
    var p = lembrar(chave);
    if (p && p.left) { el.style.left = p.left; el.style.top = p.top; el.style.right = 'auto'; el.style.bottom = 'auto'; }
    alca.addEventListener('mousedown', function (ev) {
      if (ev.button !== 0) return;
      if (ev.target && ev.target.closest && ev.target.closest('[data-botao]')) return;   // clique num botão da barra não arrasta
      var r = el.getBoundingClientRect();
      var ini = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top }, moveu = false;
      ev.preventDefault();
      var fr = el.querySelector && el.querySelector('iframe'); if (fr) fr.style.pointerEvents = 'none';   // o iframe não "engole" o mouse
      function move(e2) {
        var dx = e2.clientX - ini.x, dy = e2.clientY - ini.y;
        if (Math.abs(dx) + Math.abs(dy) > 6) moveu = true;
        if (!moveu) return;
        el.style.left = Math.min(Math.max(0, ini.left + dx), window.innerWidth - 60) + 'px';
        el.style.top = Math.min(Math.max(0, ini.top + dy), window.innerHeight - 40) + 'px';
        el.style.right = 'auto'; el.style.bottom = 'auto';
      }
      function solta() {
        if (fr) fr.style.pointerEvents = '';
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', solta);
        el._arrastou = moveu;
        if (moveu) guardar(chave, { left: el.style.left, top: el.style.top });
      }
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', solta);
    });
  }

  // ===== redimensiona por QUALQUER borda ou canto (Bruno: "aumentar e diminuir o tamanho pelo mouse") =====
  function redimensionavel(el, aoMudar) {
    var MINW = 360, MINH = 280;
    ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'].forEach(function (lado) {
      var h = document.createElement('div');
      h.setAttribute('data-lado', lado);
      var css = 'position:absolute;z-index:6;';
      if (lado === 'n') css += 'top:-5px;left:14px;right:14px;height:10px;cursor:ns-resize;';
      if (lado === 's') css += 'bottom:-5px;left:14px;right:14px;height:10px;cursor:ns-resize;';
      if (lado === 'e') css += 'right:-5px;top:14px;bottom:14px;width:10px;cursor:ew-resize;';
      if (lado === 'w') css += 'left:-5px;top:14px;bottom:14px;width:10px;cursor:ew-resize;';
      if (lado === 'ne') css += 'top:-5px;right:-5px;width:18px;height:18px;cursor:nesw-resize;';
      if (lado === 'nw') css += 'top:-5px;left:-5px;width:18px;height:18px;cursor:nwse-resize;';
      if (lado === 'sw') css += 'bottom:-5px;left:-5px;width:18px;height:18px;cursor:nesw-resize;';
      if (lado === 'se') css += 'bottom:-2px;right:-2px;width:22px;height:22px;cursor:nwse-resize;border-radius:0 0 10px 0;';
      h.style.cssText = css;
      if (lado === 'se') {   // canto com "grip" visível
        h.innerHTML = '<svg width="22" height="22" viewBox="0 0 22 22" style="display:block"><path d="M19 9 L9 19 M19 14 L14 19" stroke="rgba(246,163,80,.9)" stroke-width="2" fill="none"/></svg>';
        h.title = 'Arraste para mudar o tamanho (qualquer borda também funciona)';
      }
      h.addEventListener('mousedown', function (ev) {
        if (ev.button !== 0) return;
        ev.preventDefault(); ev.stopPropagation();
        var r = el.getBoundingClientRect();
        var ini = { x: ev.clientX, y: ev.clientY, l: r.left, t: r.top, w: r.width, h: r.height };
        var fr = el.querySelector('iframe'); if (fr) fr.style.pointerEvents = 'none';
        document.body.style.userSelect = 'none';
        function move(e2) {
          var dx = e2.clientX - ini.x, dy = e2.clientY - ini.y;
          var L = ini.l, T = ini.t, W = ini.w, H = ini.h;
          if (lado.indexOf('e') > -1) W = ini.w + dx;
          if (lado.indexOf('s') > -1) H = ini.h + dy;
          if (lado.indexOf('w') > -1) { W = ini.w - dx; L = ini.l + dx; }
          if (lado.indexOf('n') > -1) { H = ini.h - dy; T = ini.t + dy; }
          if (W < MINW) { if (lado.indexOf('w') > -1) L = ini.l + ini.w - MINW; W = MINW; }
          if (H < MINH) { if (lado.indexOf('n') > -1) T = ini.t + ini.h - MINH; H = MINH; }
          L = Math.max(0, L); T = Math.max(0, T);
          W = Math.min(W, window.innerWidth - L); H = Math.min(H, window.innerHeight - T);
          el.style.left = L + 'px'; el.style.top = T + 'px'; el.style.width = W + 'px'; el.style.height = H + 'px';
          el.style.right = 'auto'; el.style.bottom = 'auto';
        }
        function solta() {
          if (fr) fr.style.pointerEvents = '';
          document.body.style.userSelect = '';
          document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', solta);
          if (aoMudar) aoMudar();
        }
        document.addEventListener('mousemove', move); document.addEventListener('mouseup', solta);
      });
      el.appendChild(h);
    });
  }

  // ===== reconhecer o LEAD da tela =====
  var RE_TEL = /(?:\+?55\s*)?\(?\d{2}\)?\s*9?\s*\d{4}[-.\s]?\d{4}/g;
  function tela() {   // tamanho da janela (com reserva caso a aba esteja escondida e o navegador diga 0)
    return { w: window.innerWidth || document.documentElement.clientWidth || 1400, h: window.innerHeight || document.documentElement.clientHeight || 800 };
  }
  function visivel(el) {
    if (!el || !el.getBoundingClientRect) return null;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    var t = tela();
    if (r.bottom < 0 || r.top > t.h || r.right < 0 || r.left > t.w) return null;
    return r;
  }
  // varre a tela UMA vez e devolve as duas coisas: telefones ao lado de rótulos (etiq) e telefones visíveis com nota (vis)
  var ROTULOS = { telefone: 1, celular: 1, whatsapp: 1, 'número': 1, numero: 1, fone: 1 };
  function varrerTela() {
    var etiq = [], out = {}, tl = tela();
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null), n;
    while ((n = walker.nextNode())) {
      var t = n.nodeValue; if (!t) continue;
      var el = n.parentElement; if (!el || (el.closest && el.closest(NOSSOS))) continue;
      if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(el.tagName)) continue;
      var tt = t.trim();
      if (tt.length && tt.length <= 12 && el.children.length <= 1) {   // rótulo "Telefone"?
        var rot = tt.toLowerCase().replace(/[:*]$/, '').trim();
        if (ROTULOS[rot]) {
          var pai = el;
          for (var up = 0; up < 3 && pai; up++) {
            pai = pai.parentElement; if (!pai) break;
            var txt = pai.textContent || '';
            var inp = pai.querySelector && pai.querySelector('input'); if (inp && inp.value) txt += ' ' + inp.value;
            var mm = txt.match(RE_TEL);
            if (mm) { var dd = digitos(mm[0]); if (telValido(dd)) { if (etiq.indexOf(dd) === -1) etiq.push(dd); break; } }
          }
          continue;
        }
      }
      if (t.length < 8 || !/\d{4}/.test(t)) continue;
      var ms = t.match(RE_TEL); if (!ms) continue;
      var r = visivel(el); if (!r) continue;
      var fs = 12; try { fs = parseFloat(getComputedStyle(el).fontSize) || 12; } catch (e) {}
      for (var i = 0; i < ms.length; i++) {
        var d = digitos(ms[i]); if (!telValido(d)) continue;
        var nota = 0;
        if (r.top < tl.h * 0.3) nota += 2;           // em cima
        if (r.left > tl.w * 0.28) nota += 2;          // fora da lista da esquerda
        if (fs >= 14) nota += 1;                      // letra de cabeçalho
        if (!out[d] || out[d].nota < nota) out[d] = { d: d, nota: nota, el: el, top: r.top, left: r.left };
      }
    }
    var inputs = document.querySelectorAll('input');
    for (var k = 0; k < inputs.length; k++) {
      var inp2 = inputs[k], d2 = digitos(inp2.value); if (!telValido(d2)) continue;
      var rot2 = ((inp2.placeholder || '') + ' ' + (inp2.name || '') + ' ' + (inp2.getAttribute('aria-label') || '') + ' ' + (inp2.id || '')).toLowerCase();
      if (/telefone|celular|whatsapp|phone|fone/.test(rot2) && etiq.indexOf(d2) === -1) etiq.push(d2);
      if (!out[d2] && visivel(inp2)) out[d2] = { d: d2, nota: 1, el: inp2, top: 0, left: 0 };
    }
    var vis = Object.keys(out).map(function (k2) { return out[k2]; });
    vis.sort(function (a, b) { return (b.nota - a.nota) || (a.top - b.top); });
    return { etiq: etiq, vis: vis };
  }
  function pelaEtiqueta() { return varrerTela().etiq; }
  function telefonesVisiveis() { return varrerTela().vis; }
  // devolve {tel, nome, candidatos}
  function leadDaTela() {
    var sel = digitos(String(window.getSelection() || ''));
    if (telValido(sel)) return { tel: sel, nome: '', candidatos: [sel] };
    var v = varrerTela(), etiq = v.etiq, vis = v.vis;   // uma passada só pela tela
    var cand = etiq.slice();
    vis.forEach(function (v) { if (cand.indexOf(v.d) === -1) cand.push(v.d); });
    var tel = '';
    if (etiq.length === 1) tel = etiq[0];
    else if (etiq.length === 0 && vis.length === 1) tel = vis[0].d;
    else if (etiq.length === 0 && vis.length > 1 && vis[0].nota >= 3 && vis[0].nota > vis[1].nota) tel = vis[0].d;   // um claramente no cabeçalho
    var nome = tel ? nomeDaTela(tel, vis) : '';
    return { tel: tel, nome: nome, candidatos: cand };
  }
  function telDaTela() { return leadDaTela().tel; }
  // o NOME da pessoa: texto destacado (negrito / letra maior / título) perto de onde o telefone aparece
  var PALAVRAS_NAO = /^(telefone|celular|whatsapp|contato|contatos|conversa|conversas|chat|atendimento|online|offline|digitando|hoje|ontem|lead|leads|etapa|dono|respons[aá]vel|tags?|notas?|enviar|mensagem|clint|nome|e-?mail|salvar|editar|fechar|voltar|abrir|ver|mais|menos|novo|nova|neg[oó]cios?|atividades|automa[cç][oõ]es|campanhas|indicadores|todos|pesquisar|pr[oó]ximo neg[oó]cio|neg[oó]cio selecionado|programas promov|spark ?\/ ?growth|reuni[aã]o closer|ganho|perdido|aberto|origem|dono do neg[oó]cio|valor do neg[oó]cio|ler mais|trabalho|pe[cç]a ao gemini)$/i;
  function pareceNome(s) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (s.length < 2 || s.length > 70) return '';
    if (/\d{3}/.test(s) || /[@#/\\|{}<>=]/.test(s)) return '';
    if (PALAVRAS_NAO.test(s)) return '';
    if (!/[A-Za-zÀ-ÿ]{2,}/.test(s)) return '';
    return s;
  }
  // nome no CABEÇALHO da conversa: texto em destaque (negrito / letra maior) no alto da coluna do meio da tela
  function nomeDoCabecalho() {
    var tl = tela(), melhor = null, nota = -1;
    var els = document.querySelectorAll('h1,h2,h3,h4,h5,b,strong,span,div,p,a');
    for (var i = 0; i < els.length; i++) {
      var c = els[i];
      if (c.children.length > 0 || (c.closest && c.closest(NOSSOS))) continue;
      var txt = (c.textContent || '').trim(); if (!txt || txt.length > 60) continue;
      var r = visivel(c); if (!r) continue;
      if (r.top > tl.h * 0.3 || r.left < tl.w * 0.22 || r.left > tl.w * 0.78) continue;   // alto e no meio (nem lista da esquerda, nem painel da direita)
      var fw = 400, fs = 12;
      try { var cs = getComputedStyle(c); fw = parseInt(cs.fontWeight, 10) || (cs.fontWeight === 'bold' ? 700 : 400); fs = parseFloat(cs.fontSize) || 12; } catch (e) {}
      if (!(/^H[1-5]$/.test(c.tagName) || fw >= 600 || fs >= 15)) continue;
      if (/whatsapp|instagram|iphone|android|\bvia\b/i.test(txt) && /-|·|\|/.test(txt)) continue;   // subtítulo "WhatsApp - Sarah - Iphone"
      var n = pareceNome(txt); if (!n) continue;
      var pontos = fs + (fw >= 600 ? 3 : 0) - r.top / 60;
      if (pontos > nota) { nota = pontos; melhor = n; }
    }
    return melhor || '';
  }
  // nome no CAMPO "Nome" do painel do contato (input com rótulo/placeholder Nome)
  function nomeDoCampo() {
    var inputs = document.querySelectorAll('input');
    for (var k = 0; k < inputs.length; k++) {
      var inp = inputs[k], v = String(inp.value || '').trim(); if (!v) continue;
      var rot = ((inp.placeholder || '') + ' ' + (inp.name || '') + ' ' + (inp.getAttribute('aria-label') || '') + ' ' + (inp.id || '')).toLowerCase();
      var ok = /^nome\b|\bnome\b/.test(rot);
      if (!ok) { var ant = inp.previousElementSibling || (inp.parentElement && inp.parentElement.previousElementSibling); ok = !!(ant && /^nome$/i.test((ant.textContent || '').trim())); }
      if (!ok) { var lb = inp.id ? document.querySelector('label[for="' + inp.id + '"]') : null; ok = !!(lb && /^nome$/i.test((lb.textContent || '').trim())); }
      if (ok) { var n = pareceNome(v); if (n) return n; }
    }
    return '';
  }
  function nomeDaTela(tel, vis) {
    var perto = tel ? nomePertoDoTelefone(tel, vis) : '';
    return perto || nomeDoCabecalho() || nomeDoCampo() || '';
  }
  function nomePertoDoTelefone(tel, vis) {
    var base = null;
    (vis || telefonesVisiveis()).forEach(function (v) { if (!base && v.d === tel) base = v.el; });
    if (!base) return '';
    var pai = base, melhor = '';
    for (var up = 0; up < 5 && pai && !melhor; up++) {
      pai = pai.parentElement; if (!pai || pai === document.body) break;
      var cands = pai.querySelectorAll('h1,h2,h3,h4,h5,b,strong,span,div,p,a');
      for (var i = 0; i < cands.length && !melhor; i++) {
        var c = cands[i];
        if (c === base || c.contains(base) || c.children.length > 0) continue;
        var txt = (c.textContent || '').trim();
        if (!txt || RE_TEL.test(txt)) { RE_TEL.lastIndex = 0; continue; }
        RE_TEL.lastIndex = 0;
        var fw = 400, fs = 12;
        try { var cs = getComputedStyle(c); fw = parseInt(cs.fontWeight, 10) || (cs.fontWeight === 'bold' ? 700 : 400); fs = parseFloat(cs.fontSize) || 12; } catch (e) {}
        var destaque = /^H[1-5]$/.test(c.tagName) || fw >= 600 || fs >= 15;
        if (!destaque || !visivel(c)) continue;
        melhor = pareceNome(txt);
      }
    }
    return melhor;
  }

  // ===== abrir o dash numa aba própria (usado pelo "↗ aba" e pelo menu de escolha) =====
  function abrirDash(d, nome) {
    var url = DASH + '#clint=1&marcar=' + d + (nome ? '&nome=' + encodeURIComponent(nome) : '') + '&t=' + Date.now();
    try { chrome.runtime.sendMessage({ acao: 'abrirDash', url: url }); }
    catch (e) { window.open(url, 'promov_dash'); }
    fecharEscolha();
  }
  function fecharEscolha() {
    var m = document.getElementById('promov-marcar-menu');
    if (m) m.remove();
  }
  function marcar() {   // botão "marcar" quando não achou de primeira: pergunta qual telefone
    var ld = leadDaTela();
    if (ld.tel) return abrirPainelAgenda(ld.tel, 'marcar', ld.nome);
    abrirPainelAgenda('', 'agenda');
    mostrarBarraTelefone(ld.candidatos);
  }

  // ===== 📊 O DASH INTEIRO dentro da Clint (janela móvel e redimensionável) =====
  var LARGURAS = ['48vw', '66vw', '96vw'];
  var ZOOMS = [0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.25];
  function larguraAtual() { try { return localStorage.getItem('promovDashLarg') || LARGURAS[1]; } catch (e) { return LARGURAS[1]; } }
  function zoomAtual() { var z = lembrar('promovDashZoom'); return (typeof z === 'number' && z > 0) ? z : 0.9; }
  var _extraPessoa = {};   // e-mail / Instagram da pessoa da conversa (cadastro da Clint), para o dash achar o lead
  function hashDe(tel, modo, nome) {
    var h = '#clint=1&zoom=' + zoomAtual();
    var extras = (_extraPessoa.email ? '&email=' + encodeURIComponent(_extraPessoa.email) : '') + (_extraPessoa.insta ? '&insta=' + encodeURIComponent(_extraPessoa.insta) : '');
    if (modo === 'agenda') h += '&aba=agenda';
    else if (modo === 'buscar' && nome) h += '&buscar=' + encodeURIComponent(nome);   // sem telefone: procura pelo nome na aba Leads
    else if (modo === 'marcar' && !tel && nome) h += '&marcarnome=' + encodeURIComponent(nome) + extras;   // sem telefone: o dash acha por e-mail/Instagram/nome
    else if (tel && modo === 'marcar') h += '&marcar=' + tel + (nome ? '&nome=' + encodeURIComponent(nome) : '') + extras;
    else if (tel) h += '&ficha=' + tel;
    else h += '&aba=visao';   // 🏠 início: volta mesmo para a tela inicial
    return h + '&t=' + Date.now();
  }
  function tamGuardado() { return lembrar('promovPainelTam'); }
  function guardarTam(p) { guardar('promovPainelTam', { w: p.offsetWidth, h: p.offsetHeight }); guardar('promovPainelPos', { left: p.style.left, top: p.style.top }); }
  function trocarHash(alvoHash) {
    var fr0 = document.getElementById('promov-agenda-frame');
    if (!fr0) return;
    try { fr0.contentWindow.location.hash = alvoHash; } catch (e) { fr0.src = dashUrl(alvoHash); }
  }
  function mostrarBarraTelefone(candidatos) {
    var p = document.getElementById('promov-agenda-painel'); if (!p) return;
    var barra = document.getElementById('promov-barra-tel');
    if (!barra) {
      barra = document.createElement('div'); barra.id = 'promov-barra-tel';
      barra.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:7px 12px;background:#1b1f27;border-top:1px solid rgba(255,255,255,.08);color:#dfe3ee;font-family:sans-serif;font-size:12px;';
      p.insertBefore(barra, document.getElementById('promov-agenda-frame'));
    }
    barra.innerHTML = '';
    var txt = document.createElement('span'); txt.textContent = '📞 Não achei o telefone desta conversa. Cole aqui ou escolha:'; txt.style.color = '#ffd166';
    barra.appendChild(txt);
    var inp = document.createElement('input'); inp.placeholder = '(62) 99999-9999';
    inp.style.cssText = 'background:#0c0e12;border:1px solid rgba(255,255,255,.18);color:#fff;border-radius:8px;padding:5px 8px;font-size:12px;width:150px;';
    var ok = document.createElement('div'); ok.textContent = '📅 Marcar'; ok.setAttribute('data-botao', '1');
    ok.style.cssText = 'cursor:pointer;padding:5px 10px;border-radius:8px;background:rgba(255,209,102,.16);border:1px solid rgba(255,209,102,.5);color:#ffd166;font-weight:700;';
    function usar() {
      var d = digitos(inp.value);
      if (!telValido(d)) { inp.style.borderColor = '#ff6b6b'; inp.focus(); return; }
      barra.remove(); abrirPainelAgenda(d, 'marcar', '');
    }
    ok.onclick = usar; inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') usar(); });
    barra.appendChild(inp); barra.appendChild(ok);
    (candidatos || []).slice(0, 8).forEach(function (d) {
      var chip = document.createElement('div'); chip.textContent = '📱 ' + bonito(d); chip.setAttribute('data-botao', '1');
      chip.style.cssText = 'cursor:pointer;padding:4px 9px;border-radius:999px;border:1px solid rgba(110,168,255,.5);color:#6ea8ff;font-weight:700;';
      chip.onclick = function () { barra.remove(); abrirPainelAgenda(d, 'marcar', nomeDaTela(d)); };
      barra.appendChild(chip);
    });
    var x = document.createElement('div'); x.textContent = '✕'; x.setAttribute('data-botao', '1');
    x.style.cssText = 'cursor:pointer;padding:4px 8px;color:#9aa3b2;margin-left:auto;'; x.onclick = function () { barra.remove(); };
    barra.appendChild(x);
    setTimeout(function () { try { inp.focus(); } catch (e) {} }, 50);
  }
  function abrirPainelAgenda(tel, modo, nome, escondido) {   // nome mantido: o cartão do lead chama esta função
    var p = document.getElementById('promov-agenda-painel');
    var m = modo === 'marcar' ? 'marcar' : modo === 'agenda' ? 'agenda' : modo === 'buscar' ? 'buscar' : (modo === 'lead' || tel ? 'ficha' : '');
    var alvoHash = hashDe(tel, m, nome);
    if (p) {
      if (escondido) return;   // já está pré-aquecido
      p.style.display = 'flex';
      var bT = document.getElementById('promov-barra-tel'); if (bT && m !== 'agenda') bT.remove();
      trocarHash(alvoHash);
      return;
    }
    p = document.createElement('div');
    p.id = 'promov-agenda-painel';
    var tam = tamGuardado(), pos = lembrar('promovPainelPos'), tl = tela();
    var w = tam && tam.w ? Math.min(tam.w, tl.w) : Math.round(tl.w * 0.66);
    var h = tam && tam.h ? Math.min(tam.h, tl.h) : tl.h;
    var left = Math.max(0, tl.w - w), top = 0;
    if (pos && pos.left) { left = Math.min(Math.max(0, parseInt(pos.left, 10) || 0), tl.w - 80); top = Math.min(Math.max(0, parseInt(pos.top, 10) || 0), tl.h - 60); }
    p.style.cssText = 'position:fixed;top:' + top + 'px;left:' + left + 'px;width:' + w + 'px;height:' + h + 'px;min-width:360px;min-height:280px;max-width:100vw;max-height:100vh;'
      + 'overflow:visible;z-index:2147483646;background:#0c0e12;border:2px solid rgba(246,163,80,.7);border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.55);display:flex;flex-direction:column;';
    var topo = document.createElement('div');
    topo.title = 'Segure e arraste para mover a janela · as bordas e os cantos mudam o tamanho';
    topo.style.cssText = 'display:flex;align-items:center;gap:6px;padding:7px 10px;background:#14171d;color:#fff;font-family:sans-serif;font-size:12px;user-select:none;flex-wrap:wrap;cursor:move;border-radius:10px 10px 0 0;';
    function botao(txt, dica, acao, cor) {
      var b = document.createElement('div'); b.textContent = txt; b.title = dica; b.setAttribute('data-botao', '1');
      b.style.cssText = 'cursor:pointer;padding:5px 9px;border-radius:9px;border:1px solid rgba(255,255,255,.14);color:' + (cor || '#dfe3ee') + ';font-weight:700;font-size:11.5px;white-space:nowrap;';
      b.onmouseover = function () { b.style.background = 'rgba(255,255,255,.08)'; }; b.onmouseout = function () { b.style.background = ''; };
      b.onclick = function (ev) { ev.stopPropagation(); acao(); }; return b;
    }
    var tt = document.createElement('b'); tt.innerHTML = '📊 Dash Promov <span style="font-weight:400;color:#8b93a5;font-size:10.5px;">ext ' + VERSAO_EXT + '</span>'; tt.style.cssText = 'flex:1;font-size:13px;color:#f6a350;white-space:nowrap;';
    topo.appendChild(tt);
    topo.appendChild(botao('📅 marcar reunião', 'Lê o telefone da conversa aberta e abre a agenda já marcando para essa pessoa', marcar, '#ffd166'));
    topo.appendChild(botao('🔎 este contato', 'Abre no dash a ficha da pessoa desta conversa', function () {
      var ld = leadDaTela(); if (!ld.tel) { mostrarBarraTelefone(ld.candidatos); return; }
      abrirPainelAgenda(ld.tel, 'lead');
    }, '#6ea8ff'));
    topo.appendChild(botao('📆 agenda', 'Abre a agenda do dash', function () { abrirPainelAgenda('', 'agenda'); }));
    topo.appendChild(botao('🏠 início', 'Tela inicial do dash', function () { abrirPainelAgenda('', ''); }));
    topo.appendChild(botao('A−', 'Diminui o tamanho do conteúdo', function () { mudarZoom(-1); }));
    topo.appendChild(botao('A+', 'Aumenta o tamanho do conteúdo', function () { mudarZoom(1); }));
    topo.appendChild(botao('⟷', 'Alterna: metade, dois terços ou a tela toda (as bordas também redimensionam)', function () {
      var i = (LARGURAS.indexOf(larguraAtual()) + 1) % LARGURAS.length;
      try { localStorage.setItem('promovDashLarg', LARGURAS[i]); } catch (e) {}
      var fr = parseFloat(LARGURAS[i]) / 100;
      var nw = Math.round(window.innerWidth * fr);
      p.style.width = nw + 'px'; p.style.height = window.innerHeight + 'px'; p.style.top = '0px'; p.style.left = Math.max(0, window.innerWidth - nw) + 'px';
      guardarTam(p);
    }));
    topo.appendChild(botao('↗ aba', 'Abre o dash numa aba própria', function () {
      var url = DASH + '?v=' + Date.now();
      try { chrome.runtime.sendMessage({ acao: 'abrirDash', url: url }); } catch (e) { window.open(url, 'promov_dash'); }
    }));
    topo.appendChild(botao('✕', 'Fecha a janela (o dash continua carregado)', function () { p.style.display = 'none'; }, '#9aa3b2'));
    var fr = document.createElement('iframe');
    fr.id = 'promov-agenda-frame';
    fr.src = dashUrl(alvoHash);   // sempre a versão publicada do dash (cache por versão)
    fr.style.cssText = 'flex:1;border:0;width:100%;background:#0c0e12;border-radius:0 0 10px 10px;min-height:0;';
    fr.setAttribute('allow', 'clipboard-write');
    p.appendChild(topo); p.appendChild(fr);
    if (escondido) p.style.display = 'none';   // pré-aquecido: o dash carrega por trás; o clique só mostra
    document.body.appendChild(p);
    arrastavel(p, topo, 'promovPainelPos');   // arrasta pelo topo; a posição fica guardada
    redimensionavel(p, function () { guardarTam(p); });
    window.addEventListener('resize', function () {   // a janela do navegador mudou: mantém o painel dentro dela
      var r = p.getBoundingClientRect();
      if (r.right > window.innerWidth) p.style.left = Math.max(0, window.innerWidth - r.width) + 'px';
      if (r.bottom > window.innerHeight) p.style.top = Math.max(0, window.innerHeight - r.height) + 'px';
    });
  }
  function mudarZoom(passo) {
    var z = zoomAtual(), i = ZOOMS.indexOf(z); if (i < 0) i = 3;
    i = Math.min(ZOOMS.length - 1, Math.max(0, i + passo));
    guardar('promovDashZoom', ZOOMS[i]);
    trocarHash('#clint=1&zoom=' + ZOOMS[i] + '&t=' + Date.now());   // o dash só troca o tamanho, sem sair da tela
  }
  // pré-aquece: 5 s depois de abrir a Clint, o dash já começa a carregar escondido, na agenda (Bruno 09/09/2026: "mais rápido")
  var _preAqueceu = false;
  function preAquecer() {
    if (_preAqueceu || document.getElementById('promov-agenda-painel')) return;
    _preAqueceu = true;
    try { abrirPainelAgenda('', 'agenda', '', true); } catch (e) {}
  }
  setTimeout(preAquecer, 5000);
  function alternarPainelAgenda() {
    var p = document.getElementById('promov-agenda-painel');
    if (p && p.style.display !== 'none') { p.style.display = 'none'; return; }   // clicou de novo = fecha
    // Bruno 08/09/2026: abre DIRETO no "marcar reunião" da pessoa da conversa aberta (não na tela inicial)
    var ld = leadDaTela();
    var nomeR = _extraPessoa.nome || '';
    if (ld.tel) { abrirPainelAgenda(ld.tel, 'marcar', nomeR || ld.nome); return; }
    var nomeSo = nomeR || nomeDaTela('', []);
    if (nomeSo) { abrirPainelAgenda('', 'marcar', nomeSo); return; }   // sem telefone: o dash acha por e-mail/Instagram/nome e já marca
    abrirPainelAgenda('', 'agenda');
    mostrarBarraTelefone(ld.candidatos);
  }

  var btnAg = document.createElement('div');
  btnAg.id = 'promov-agenda-btn';
  btnAg.textContent = '📊 Dash';
  btnAg.title = 'Um clique abre a agenda já marcando reunião para a pessoa desta conversa; outro clique fecha. Segure e arraste para mudar o botão de lugar.';
  btnAg.style.cssText = 'position:fixed;right:22px;bottom:22px;z-index:2147483647;background:#14171d;color:#f6a350;border:1px solid rgba(246,163,80,.6);font-family:sans-serif;font-size:13px;font-weight:800;padding:10px 14px;border-radius:999px;cursor:pointer;box-shadow:0 6px 24px rgba(0,0,0,.45);user-select:none;';
  btnAg.onclick = function () { if (btnAg._arrastou) { btnAg._arrastou = false; return; } alternarPainelAgenda(); };
  document.body.appendChild(btnAg);
  arrastavel(btnAg, btnAg, 'promovBtnAgendaPos');

  var btn = btnAg;   // referencia mantida: o cartao do lead se apoia no botao

  // ===== reconhece o LEAD da conversa aberta e mostra os dados dele =====
  var PLANILHA_CSV = 'https://docs.google.com/spreadsheets/d/1xJykoW0UHr5hA-ELo5nV8uBkYykRG6OQdmMvDlUnhVg/export?format=csv&gid=2012456321';
  var _robo = null, _roboEm = 0, _csv = null, _csvEm = 0, _leadInfo = {}, _telAtual = '';

  function acharRobo(cb) {   // o endereço do robô muda a cada implantação: robo.txt (publicado junto com o dash) ou, sem ele, o dash inteiro
    if (!_robo) { var g = lembrar('promovRoboUrl'); if (g && g.url && Date.now() - (g.em || 0) < 3600000) { _robo = g.url; _roboEm = g.em; } }
    if (_robo && Date.now() - _roboEm < 3600000) return cb(_robo);
    var RE_ROBO = /https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec/;
    function achou(url) { _robo = url; _roboEm = Date.now(); guardar('promovRoboUrl', { url: url, em: _roboEm }); cb(url); }
    fetch(DASH + 'robo.txt?t=' + Date.now()).then(function (r) { return r.ok ? r.text() : ''; }).then(function (t) {
      var m = String(t || '').match(RE_ROBO);
      if (m) return achou(m[0]);
      return fetch(DASH + 'index.html?t=' + Date.now()).then(function (r) { return r.text(); }).then(function (h) {
        var m2 = h.match(RE_ROBO); if (m2) achou(m2[0]); else cb(_robo);
      });
    }).catch(function () { cb(_robo); });
  }
  setTimeout(function () { try { acharRobo(function () {}); } catch (e) {} }, 1500);   // já deixa o endereço pronto
  function lerCSV(txt) {   // separa respeitando aspas (nomes com vírgula)
    var linhas = [], linha = [], campo = '', dentro = false;
    for (var i = 0; i < txt.length; i++) {
      var ch = txt[i];
      if (dentro) {
        if (ch === '"') { if (txt[i + 1] === '"') { campo += '"'; i++; } else dentro = false; }
        else campo += ch;
      } else if (ch === '"') dentro = true;
      else if (ch === ',') { linha.push(campo); campo = ''; }
      else if (ch === '\n') { linha.push(campo); linhas.push(linha); linha = []; campo = ''; }
      else if (ch !== '\r') campo += ch;
    }
    if (campo || linha.length) { linha.push(campo); linhas.push(linha); }
    return linhas;
  }
  function carregarCSV(cb) {   // planilha de reuniões (pública para leitura), guardada por 3 min
    if (_csv && Date.now() - _csvEm < 180000) return cb(_csv);
    if (carregarCSV._fila) { carregarCSV._fila.push(cb); return; }
    carregarCSV._fila = [cb];
    fetch(PLANILHA_CSV + '&t=' + Date.now()).then(function (r) { return r.text(); }).then(function (t) {
      _csv = lerCSV(t); _csvEm = Date.now();
      var fila = carregarCSV._fila; carregarCSV._fila = null; fila.forEach(function (f) { try { f(_csv); } catch (e) {} });
    }).catch(function () { var fila = carregarCSV._fila; carregarCSV._fila = null; fila.forEach(function (f) { try { f(null); } catch (e) {} }); });
  }
  setTimeout(function () { try { carregarCSV(function () {}); } catch (e) {} }, 800);   // pré-carrega: o 1º cartão sai na hora
  function reunioesDoTel(d, cb) {
    function usa() {
      var head = _csv[0].map(function (h) { return String(h).toLowerCase(); });
      var iN = head.indexOf('nome'), iT = head.indexOf('telefone'), iS = head.indexOf('status'), iD = head.indexOf('data');
      var t8 = d.slice(-8), achou = null;
      for (var i = 1; i < _csv.length; i++) {
        var r = _csv[i];
        if (String(r[iT] || '').replace(/\D/g, '').slice(-8) !== t8) continue;
        achou = { nome: r[iN] || '', status: r[iS] || '', data: r[iD] || '' };   // fica a mais recente (de cima para baixo)
      }
      cb(achou);
    }
    carregarCSV(function (c) { if (!c) return cb(null); usa(); });
  }
  function cadastroClint(d, cb) {   // nome/etapa/dona pelo robô do dash
    acharRobo(function (robo) {
      if (!robo) return cb(null);
      fetch(robo + '?callback=cb&payload=' + encodeURIComponent(JSON.stringify({ action: 'clintLead', telefone: d })))
        .then(function (r) { return r.text(); })
        .then(function (t) { cb(JSON.parse(t.replace(/^cb\(/, '').replace(/\)$/, ''))); })
        .catch(function () { cb(null); });
    });
  }
  function mostrarCartao(d, reuniao, clint, carregando) {
    var card = document.getElementById('promov-lead-card');
    if (!card) { card = document.createElement('div'); card.id = 'promov-lead-card'; document.body.appendChild(card); }
    var nome = (reuniao && reuniao.nome) || (clint && clint.nomeClint) || nomeDaTela(d) || '';
    var linhas = [];
    linhas.push('<b style="color:#f6a350;">👤 ' + (nome || bonito(d)) + '</b>');
    card._tel = d; card._nome = nome;
    if (reuniao) linhas.push('📇 ' + (reuniao.status || 'reunião') + (reuniao.data ? ' · ' + reuniao.data : ''));
    else if (carregando && carregando.planilha) linhas.push('<span style="color:#8b93a5;">⏳ olhando a planilha…</span>');
    else linhas.push('🆕 sem reunião registrada');
    if (clint && clint.achou) linhas.push('🟣 ' + [clint.etapaClint || '', clint.dono ? '✋ ' + clint.dono : '', clint.viaChat !== undefined ? '<span style="color:#8b93a5;">cadastro da Clint ✓</span>' : ''].filter(Boolean).join(' · '));
    else if (carregando && carregando.clint) linhas.push('<span style="color:#8b93a5;">⏳ perguntando à Clint…</span>');
    var r = btn.getBoundingClientRect();
    linhas.push('<span style="color:#ffd166;font-weight:700;">📅 clique para marcar reunião</span> <span style="color:#6ea8ff;">· 🔎 ver ficha</span>');
    card.innerHTML = linhas.join('<br>');
    card.style.cssText = 'position:fixed;left:' + Math.max(6, r.left - 40) + 'px;top:' + Math.max(6, r.top - 104) + 'px;z-index:2147483647;background:#14171d;color:#dfe3ee;border:1px solid rgba(246,163,80,.5);border-radius:12px;padding:9px 13px;font-family:sans-serif;font-size:12px;line-height:1.5;box-shadow:0 10px 26px rgba(0,0,0,.45);max-width:280px;cursor:pointer;';
    card.onclick = function (ev) {
      if (!card._tel) return;
      var t = (ev.target && ev.target.textContent) || '';
      if (t.indexOf('ver ficha') !== -1) abrirPainelAgenda(card._tel, 'lead'); else abrirPainelAgenda(card._tel, 'marcar', card._nome);
    };
  }
  function esconderCartao() {
    var card = document.getElementById('promov-lead-card');
    if (card) card.remove();
  }
  function mostrarCartaoSemTelefone(nome) {
    var card = document.getElementById('promov-lead-card');
    if (!card) { card = document.createElement('div'); card.id = 'promov-lead-card'; document.body.appendChild(card); }
    var r = btn.getBoundingClientRect();
    card._tel = ''; card._nome = nome;
    card.innerHTML = '<b style="color:#f6a350;">👤 ' + nome.replace(/</g, '&lt;') + '</b><br><span style="color:#8b93a5;">sem telefone nesta tela' + (_extraPessoa.email || _extraPessoa.insta ? ' · achado pelo cadastro da Clint' : '') + '</span><br><span style="color:#ffd166;font-weight:700;">📅 clique para marcar reunião</span>';
    card.style.cssText = 'position:fixed;left:' + Math.max(6, r.left - 40) + 'px;top:' + Math.max(6, r.top - 90) + 'px;z-index:2147483647;background:#14171d;color:#dfe3ee;border:1px solid rgba(246,163,80,.5);border-radius:12px;padding:9px 13px;font-family:sans-serif;font-size:12px;line-height:1.5;box-shadow:0 10px 26px rgba(0,0,0,.45);max-width:280px;cursor:pointer;';
    card.onclick = function () { abrirPainelAgenda('', 'marcar', card._nome); };
  }
  // ===== ids da Clint capturados dos pedidos internos da página (chat/contato abertos) =====
  var CLINT_IDS = { chat: '', contato: '', em: 0 }, _idsResolvidos = {};
  var RE_ID = /\/(chats?|contacts?|contatos?|conversas?)\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})(?![0-9a-f-])/i;
  function anotarUrlClint(u) {
    var m = String(u || '').match(RE_ID); if (!m) return;
    var tipo = m[1].toLowerCase(), id = m[2].toLowerCase();
    if (/^chat|^conversa/.test(tipo)) { if (CLINT_IDS.chat !== id) { CLINT_IDS.chat = id; CLINT_IDS.contato = ''; CLINT_IDS.em = Date.now(); } }
    else { if (CLINT_IDS.contato !== id) { CLINT_IDS.contato = id; CLINT_IDS.em = Date.now(); } }
  }
  try {
    performance.getEntriesByType('resource').forEach(function (e) { anotarUrlClint(e.name); });
    new PerformanceObserver(function (lista) { lista.getEntries().forEach(function (e) { anotarUrlClint(e.name); }); }).observe({ type: 'resource', buffered: true });
  } catch (e) {}
  // pergunta ao robô quem é o contato desse chat (cache de 10 min por id)
  function contatoPeloRobo(ids, cb) {
    var chave = ids.contato ? 'c:' + ids.contato : (ids.chat ? 'h:' + ids.chat : '');
    if (!chave) return cb(null);
    var g = _idsResolvidos[chave];
    if (g && Date.now() - g.em < 600000) return cb(g.dados);
    acharRobo(function (robo) {
      if (!robo) return cb(null);
      var pedido = ids.contato ? { action: 'clintContatoDoChat', contato: ids.contato } : { action: 'clintContatoDoChat', chat: ids.chat };
      fetch(robo + '?callback=cb&payload=' + encodeURIComponent(JSON.stringify(pedido)))
        .then(function (r) { return r.text(); })
        .then(function (t) { var d = JSON.parse(t.replace(/^cb\(/, '').replace(/\)$/, '')); _idsResolvidos[chave] = { em: Date.now(), dados: d }; cb(d); })
        .catch(function () { cb(null); });
    });
  }
  var _chaveClint = '';
  function vigiarLead() {
    if (!estaNoAtendimento()) { _telAtual = ''; _chaveClint = ''; esconderCartao(); return; }
    // 1º caminho (v2.6): id capturado dos pedidos da Clint → cadastro pelo robô
    var chaveIds = CLINT_IDS.contato ? 'c:' + CLINT_IDS.contato : (CLINT_IDS.chat ? 'h:' + CLINT_IDS.chat : '');
    if (chaveIds && chaveIds !== _chaveClint) {
      _chaveClint = chaveIds; _extraPessoa = {};
      var idsAgora = { chat: CLINT_IDS.chat, contato: CLINT_IDS.contato };
      contatoPeloRobo(idsAgora, function (d) {
        if (_chaveClint !== chaveIds) return;   // já trocou de conversa
        if (d && d.success && d.achou) {
          var instaV = d.instaClint && typeof d.instaClint === 'object' ? (d.instaClint.username || '') : String(d.instaClint || '');
          _extraPessoa = { email: String(d.emailClint || ''), insta: instaV, nome: String(d.nomeClint || '') };
          var tel = digitos(d.telefoneClint || '');
          _telAtual = telValido(tel) ? tel : ('nome:' + (d.nomeClint || ''));
          _leadInfo[tel || d.nomeClint] = { reuniao: null, clint: d, faltaPlanilha: !!tel, faltaClint: false, pronto: !tel };
          if (telValido(tel)) {
            mostrarCartao(tel, null, d, { planilha: true, clint: false });
            reunioesDoTel(tel, function (reuniao) { var info = _leadInfo[tel]; if (info) { info.reuniao = reuniao; info.faltaPlanilha = false; info.pronto = true; } if (_telAtual === tel) mostrarCartao(tel, reuniao, d); });
          } else if (d.nomeClint) mostrarCartaoSemTelefone(d.nomeClint);
        }
        // não achou pelo id: a leitura da tela (abaixo) continua valendo no próximo tique
      });
      return;
    }
    if (chaveIds && _telAtual) return;   // já resolvido pelo id: não deixa a leitura da tela sobrescrever
    var ld = leadDaTela();
    var d = ld.tel;
    if (!d) {   // sem telefone: se der para ler o nome no cabeçalho, mostra o cartão mesmo assim (contatos do Instagram)
      var nomeSo = nomeDaTela('', []);
      var chaveN = nomeSo ? 'nome:' + nomeSo : '';
      if (chaveN === _telAtual) return;
      _telAtual = chaveN;
      if (nomeSo) mostrarCartaoSemTelefone(nomeSo); else esconderCartao();
      return;
    }
    if (d === _telAtual) return;
    _telAtual = d;
    if (_leadInfo[d] && _leadInfo[d].pronto) { mostrarCartao(d, _leadInfo[d].reuniao, _leadInfo[d].clint); return; }
    // cartão na hora (nome lido da tela) e as duas buscas em paralelo; cada uma completa o cartão quando chega
    var info = _leadInfo[d] = { reuniao: null, clint: null, faltaPlanilha: true, faltaClint: true, pronto: false };
    var pinta = function () { if (_telAtual === d) mostrarCartao(d, info.reuniao, info.clint, { planilha: info.faltaPlanilha, clint: info.faltaClint }); };
    pinta();
    reunioesDoTel(d, function (reuniao) { info.reuniao = reuniao; info.faltaPlanilha = false; info.pronto = !info.faltaClint; pinta(); });
    cadastroClint(d, function (clint) { info.clint = clint; info.faltaClint = false; info.pronto = !info.faltaPlanilha; pinta(); });
  }

  // ===== o cartão do lead aparece nas telas de CONVERSA (a Clint troca de tela sem recarregar) =====
  function estaNoAtendimento() { return /chat|inbox|atendimento|conversa|whatsapp|mensage/i.test(location.pathname + location.search); }
  function ajustaVisibilidade() {
    if (document.hidden) return;   // aba da Clint escondida: não gasta processador
    // o botão do dash fica em TODA a Clint (Bruno 08/09/2026); o cartão do lead só na conversa
    if (!estaNoAtendimento()) fecharEscolha();
    try { vigiarLead(); } catch (e) {}
  }
  ajustaVisibilidade();
  setInterval(ajustaVisibilidade, 2000);
})();
