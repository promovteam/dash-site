// ===== Promov · Dash na Clint (extensão) v2.3 — 08/09/2026 =====
// v2.3 (Bruno 08/09/2026): o botão 📊 Dash abre DIRETO no "marcar reunião" para a pessoa da conversa
//   aberta (lê telefone E nome da tela da Clint); janela com bordas e cantos para redimensionar e
//   barra de cima para arrastar; botões A− / A+ para o tamanho do conteúdo; a versão aparece no topo.
// v2.1: janela móvel e redimensionável, botões início/agenda, funciona em app.clint.digital e app.useclint.com
// O conteúdo é sempre o dash publicado (?v=agora): atualizou o dash, atualizou aqui.
// Ordem de procura do telefone: 1) texto selecionado; 2) campo "Telefone/WhatsApp" do painel de
// contato; 3) telefones visíveis na tela, preferindo o do cabeçalho da conversa; se ficar em
// dúvida, mostra os candidatos e deixa colar o número.
(function () {
  if (document.getElementById('promov-agenda-btn')) return;

  var VERSAO_EXT = '2.3';
  var DASH = 'https://promovteam.github.io/dash-site/';
  var NOSSOS = '#promov-agenda-painel,#promov-lead-card,#promov-marcar-menu,#promov-agenda-btn';

  function digitos(s) {
    var d = String(s || '').replace(/\D/g, '');
    if (d.indexOf('55') === 0 && d.length >= 12) d = d.slice(2);   // tira o +55
    return d;
  }
  function telValido(d) { return d.length === 10 || d.length === 11; }
  function bonito(d) {
    if (!telValido(d)) return d;
    return '(' + d.slice(0, 2) + ') ' + d.slice(2, d.length - 4) + '-' + d.slice(-4);
  }
  function guardar(chave, v) { try { localStorage.setItem(chave, JSON.stringify(v)); } catch (e) {} }
  function lembrar(chave) { try { return JSON.parse(localStorage.getItem(chave) || 'null'); } catch (e) { return null; } }

  // ===== arrasta um elemento pela alça e lembra onde ficou (clique curto continua sendo clique) =====
  function arrastavel(el, alca, chave) {
    var p = lembrar(chave);
    if (p && p.left) { el.style.left = p.left; el.style.top = p.top; el.style.right = 'auto'; el.style.bottom = 'auto'; }
    alca.addEventListener('mousedown', function (ev) {
      if (ev.button !== 0) return;
      if (ev.target && ev.target.closest && ev.target.closest('[data-botao]')) return;   // clique num botão da barra não arrasta
      var r = el.getBoundingClientRect();
      var ini = { x: ev.clientX, y: ev.clientY, left: r.left, top: r.top }, moveu = false;
      ev.preventDefault();
      var fr = el.querySelector && el.querySelector('iframe'); if (fr) fr.style.pointerEvents = 'none';   // o iframe não "engole" o mouse
      function move(e2) {
        var dx = e2.clientX - ini.x, dy = e2.clientY - ini.y;
        if (Math.abs(dx) + Math.abs(dy) > 6) moveu = true;
        if (!moveu) return;
        el.style.left = Math.min(Math.max(0, ini.left + dx), window.innerWidth - 60) + 'px';
        el.style.top = Math.min(Math.max(0, ini.top + dy), window.innerHeight - 40) + 'px';
        el.style.right = 'auto'; el.style.bottom = 'auto';
      }
      function solta() {
        if (fr) fr.style.pointerEvents = '';
        document.removeEventListener('mousemove', move);
        document.removeEventListener('mouseup', solta);
        el._arrastou = moveu;
        if (moveu) guardar(chave, { left: el.style.left, top: el.style.top });
      }
      document.addEventListener('mousemove', move);
      document.addEventListener('mouseup', solta);
    });
  }

  // ===== redimensiona por QUALQUER borda ou canto (Bruno: "aumentar e diminuir o tamanho pelo mouse") =====
  function redimensionavel(el, aoMudar) {
    var MINW = 360, MINH = 280;
    ['n', 's', 'e', 'w', 'ne', 'nw', 'se', 'sw'].forEach(function (lado) {
      var h = document.createElement('div');
      h.setAttribute('data-lado', lado);
      var css = 'position:absolute;z-index:6;';
      if (lado === 'n') css += 'top:-5px;left:14px;right:14px;height:10px;cursor:ns-resize;';
      if (lado === 's') css += 'bottom:-5px;left:14px;right:14px;height:10px;cursor:ns-resize;';
      if (lado === 'e') css += 'right:-5px;top:14px;bottom:14px;width:10px;cursor:ew-resize;';
      if (lado === 'w') css += 'left:-5px;top:14px;bottom:14px;width:10px;cursor:ew-resize;';
      if (lado === 'ne') css += 'top:-5px;right:-5px;width:18px;height:18px;cursor:nesw-resize;';
      if (lado === 'nw') css += 'top:-5px;left:-5px;width:18px;height:18px;cursor:nwse-resize;';
      if (lado === 'sw') css += 'bottom:-5px;left:-5px;width:18px;height:18px;cursor:nesw-resize;';
      if (lado === 'se') css += 'bottom:-2px;right:-2px;width:22px;height:22px;cursor:nwse-resize;border-radius:0 0 10px 0;';
      h.style.cssText = css;
      if (lado === 'se') {   // canto com "grip" visível
        h.innerHTML = '<svg width="22" height="22" viewBox="0 0 22 22" style="display:block"><path d="M19 9 L9 19 M19 14 L14 19" stroke="rgba(246,163,80,.9)" stroke-width="2" fill="none"/></svg>';
        h.title = 'Arraste para mudar o tamanho (qualquer borda também funciona)';
      }
      h.addEventListener('mousedown', function (ev) {
        if (ev.button !== 0) return;
        ev.preventDefault(); ev.stopPropagation();
        var r = el.getBoundingClientRect();
        var ini = { x: ev.clientX, y: ev.clientY, l: r.left, t: r.top, w: r.width, h: r.height };
        var fr = el.querySelector('iframe'); if (fr) fr.style.pointerEvents = 'none';
        document.body.style.userSelect = 'none';
        function move(e2) {
          var dx = e2.clientX - ini.x, dy = e2.clientY - ini.y;
          var L = ini.l, T = ini.t, W = ini.w, H = ini.h;
          if (lado.indexOf('e') > -1) W = ini.w + dx;
          if (lado.indexOf('s') > -1) H = ini.h + dy;
          if (lado.indexOf('w') > -1) { W = ini.w - dx; L = ini.l + dx; }
          if (lado.indexOf('n') > -1) { H = ini.h - dy; T = ini.t + dy; }
          if (W < MINW) { if (lado.indexOf('w') > -1) L = ini.l + ini.w - MINW; W = MINW; }
          if (H < MINH) { if (lado.indexOf('n') > -1) T = ini.t + ini.h - MINH; H = MINH; }
          L = Math.max(0, L); T = Math.max(0, T);
          W = Math.min(W, window.innerWidth - L); H = Math.min(H, window.innerHeight - T);
          el.style.left = L + 'px'; el.style.top = T + 'px'; el.style.width = W + 'px'; el.style.height = H + 'px';
          el.style.right = 'auto'; el.style.bottom = 'auto';
        }
        function solta() {
          if (fr) fr.style.pointerEvents = '';
          document.body.style.userSelect = '';
          document.removeEventListener('mousemove', move); document.removeEventListener('mouseup', solta);
          if (aoMudar) aoMudar();
        }
        document.addEventListener('mousemove', move); document.addEventListener('mouseup', solta);
      });
      el.appendChild(h);
    });
  }

  // ===== reconhecer o LEAD da tela =====
  var RE_TEL = /(?:\+?55\s*)?\(?\d{2}\)?\s*9?\s*\d{4}[-.\s]?\d{4}/g;
  function tela() {   // tamanho da janela (com reserva caso a aba esteja escondida e o navegador diga 0)
    return { w: window.innerWidth || document.documentElement.clientWidth || 1400, h: window.innerHeight || document.documentElement.clientHeight || 800 };
  }
  function visivel(el) {
    if (!el || !el.getBoundingClientRect) return null;
    var r = el.getBoundingClientRect();
    if (!r.width || !r.height) return null;
    var t = tela();
    if (r.bottom < 0 || r.top > t.h || r.right < 0 || r.left > t.w) return null;
    return r;
  }
  // 2) valor ao lado do rótulo "Telefone" (painel Contato da Clint) — também em campos de digitar
  function pelaEtiqueta() {
    var achados = [];
    var els = document.querySelectorAll('label, span, div, p, b, strong, dt, th');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if (el.children.length > 1 || (el.closest && el.closest(NOSSOS))) continue;
      var t = (el.textContent || '').trim().toLowerCase().replace(/[:*]$/, '').trim();
      if (t !== 'telefone' && t !== 'celular' && t !== 'whatsapp' && t !== 'número' && t !== 'numero' && t !== 'fone') continue;
      var pai = el;
      for (var up = 0; up < 3 && pai; up++) {
        pai = pai.parentElement;
        if (!pai) break;
        var txt = pai.textContent || '';
        var inp = pai.querySelector && pai.querySelector('input');
        if (inp && inp.value) txt += ' ' + inp.value;
        var m = txt.match(RE_TEL);
        if (m) { var d = digitos(m[0]); if (telValido(d)) { if (achados.indexOf(d) === -1) achados.push(d); break; } }
      }
    }
    var inputs = document.querySelectorAll('input');   // campo cujo nome/placeholder fala de telefone
    for (var k = 0; k < inputs.length; k++) {
      var inp2 = inputs[k];
      var rot = ((inp2.placeholder || '') + ' ' + (inp2.name || '') + ' ' + (inp2.getAttribute('aria-label') || '') + ' ' + (inp2.id || '')).toLowerCase();
      if (!/telefone|celular|whatsapp|phone|fone/.test(rot)) continue;
      var d2 = digitos(inp2.value); if (telValido(d2) && achados.indexOf(d2) === -1) achados.push(d2);
    }
    return achados;
  }
  // 3) telefones VISÍVEIS na tela, com nota: cabeçalho da conversa (em cima, no meio/direita, letra maior) ganha
  function telefonesVisiveis() {
    var out = {};
    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);
    var n;
    while ((n = walker.nextNode())) {
      var t = n.nodeValue; if (!t || t.length < 8 || !/\d{4}/.test(t)) continue;
      var el = n.parentElement; if (!el || (el.closest && el.closest(NOSSOS))) continue;
      if (/^(SCRIPT|STYLE|NOSCRIPT|TEXTAREA)$/.test(el.tagName)) continue;
      var ms = t.match(RE_TEL); if (!ms) continue;
      var r = visivel(el); if (!r) continue;
      var fs = 12; try { fs = parseFloat(getComputedStyle(el).fontSize) || 12; } catch (e) {}
      var tl = tela();
      for (var i = 0; i < ms.length; i++) {
        var d = digitos(ms[i]); if (!telValido(d)) continue;
        var nota = 0;
        if (r.top < tl.h * 0.3) nota += 2;           // em cima
        if (r.left > tl.w * 0.28) nota += 2;          // fora da lista da esquerda
        if (fs >= 14) nota += 1;                                   // letra de cabeçalho
        if (!out[d] || out[d].nota < nota) out[d] = { d: d, nota: nota, el: el, top: r.top, left: r.left };
      }
    }
    var inputs = document.querySelectorAll('input');
    for (var k = 0; k < inputs.length; k++) {
      var d2 = digitos(inputs[k].value); if (!telValido(d2) || !visivel(inputs[k])) continue;
      if (!out[d2]) out[d2] = { d: d2, nota: 1, el: inputs[k], top: 0, left: 0 };
    }
    var lista = Object.keys(out).map(function (k2) { return out[k2]; });
    lista.sort(function (a, b) { return (b.nota - a.nota) || (a.top - b.top); });
    return lista;
  }
  // devolve {tel, nome, candidatos}
  function leadDaTela() {
    var sel = digitos(String(window.getSelection() || ''));
    if (telValido(sel)) return { tel: sel, nome: '', candidatos: [sel] };
    var etiq = pelaEtiqueta();
    var vis = telefonesVisiveis();
    var cand = etiq.slice();
    vis.forEach(function (v) { if (cand.indexOf(v.d) === -1) cand.push(v.d); });
    var tel = '';
    if (etiq.length === 1) tel = etiq[0];
    else if (etiq.length === 0 && vis.length === 1) tel = vis[0].d;
    else if (etiq.length === 0 && vis.length > 1 && vis[0].nota >= 3 && vis[0].nota > vis[1].nota) tel = vis[0].d;   // um claramente no cabeçalho
    var nome = tel ? nomeDaTela(tel, vis) : '';
    return { tel: tel, nome: nome, candidatos: cand };
  }
  function telDaTela() { return leadDaTela().tel; }
  // o NOME da pessoa: texto destacado (negrito / letra maior / título) perto de onde o telefone aparece
  var PALAVRAS_NAO = /^(telefone|celular|whatsapp|contato|contatos|conversa|conversas|chat|atendimento|online|offline|digitando|hoje|ontem|lead|leads|etapa|dono|respons[aá]vel|tags?|notas?|enviar|mensagem|clint|nome|e-?mail|salvar|editar|fechar|voltar|abrir|ver|mais|menos|novo|nova)$/i;
  function pareceNome(s) {
    s = String(s || '').replace(/\s+/g, ' ').trim();
    if (s.length < 2 || s.length > 70) return '';
    if (/\d{3}/.test(s) || /[@#/\\|{}<>=]/.test(s)) return '';
    if (PALAVRAS_NAO.test(s)) return '';
    if (!/[A-Za-zÀ-ÿ]{2,}/.test(s)) return '';
    return s;
  }
  function nomeDaTela(tel, vis) {
    var base = null;
    (vis || telefonesVisiveis()).forEach(function (v) { if (!base && v.d === tel) base = v.el; });
    if (!base) return '';
    var pai = base, melhor = '';
    for (var up = 0; up < 5 && pai && !melhor; up++) {
      pai = pai.parentElement; if (!pai || pai === document.body) break;
      var cands = pai.querySelectorAll('h1,h2,h3,h4,h5,b,strong,span,div,p,a');
      for (var i = 0; i < cands.length && !melhor; i++) {
        var c = cands[i];
        if (c === base || c.contains(base) || c.children.length > 0) continue;
        var txt = (c.textContent || '').trim();
        if (!txt || RE_TEL.test(txt)) { RE_TEL.lastIndex = 0; continue; }
        RE_TEL.lastIndex = 0;
        var fw = 400, fs = 12;
        try { var cs = getComputedStyle(c); fw = parseInt(cs.fontWeight, 10) || (cs.fontWeight === 'bold' ? 700 : 400); fs = parseFloat(cs.fontSize) || 12; } catch (e) {}
        var destaque = /^H[1-5]$/.test(c.tagName) || fw >= 600 || fs >= 15;
        if (!destaque || !visivel(c)) continue;
        melhor = pareceNome(txt);
      }
    }
    return melhor;
  }

  // ===== abrir o dash numa aba própria (usado pelo "↗ aba" e pelo menu de escolha) =====
  function abrirDash(d, nome) {
    var url = DASH + '#clint=1&marcar=' + d + (nome ? '&nome=' + encodeURIComponent(nome) : '') + '&t=' + Date.now();
    try { chrome.runtime.sendMessage({ acao: 'abrirDash', url: url }); }
    catch (e) { window.open(url, 'promov_dash'); }
    fecharEscolha();
  }
  function fecharEscolha() {
    var m = document.getElementById('promov-marcar-menu');
    if (m) m.remove();
  }
  function marcar() {   // botão "marcar" quando não achou de primeira: pergunta qual telefone
    var ld = leadDaTela();
    if (ld.tel) return abrirPainelAgenda(ld.tel, 'marcar', ld.nome);
    abrirPainelAgenda('', 'agenda');
    mostrarBarraTelefone(ld.candidatos);
  }

  // ===== 📊 O DASH INTEIRO dentro da Clint (janela móvel e redimensionável) =====
  var LARGURAS = ['48vw', '66vw', '96vw'];
  var ZOOMS = [0.6, 0.7, 0.8, 0.9, 1, 1.1, 1.25];
  function larguraAtual() { try { return localStorage.getItem('promovDashLarg') || LARGURAS[1]; } catch (e) { return LARGURAS[1]; } }
  function zoomAtual() { var z = lembrar('promovDashZoom'); return (typeof z === 'number' && z > 0) ? z : 0.9; }
  function hashDe(tel, modo, nome) {
    var h = '#clint=1&zoom=' + zoomAtual();
    if (modo === 'agenda') h += '&aba=agenda';
    else if (tel && modo === 'marcar') h += '&marcar=' + tel + (nome ? '&nome=' + encodeURIComponent(nome) : '');
    else if (tel) h += '&ficha=' + tel;
    else h += '&aba=visao';   // 🏠 início: volta mesmo para a tela inicial
    return h + '&t=' + Date.now();
  }
  function tamGuardado() { return lembrar('promovPainelTam'); }
  function guardarTam(p) { guardar('promovPainelTam', { w: p.offsetWidth, h: p.offsetHeight }); guardar('promovPainelPos', { left: p.style.left, top: p.style.top }); }
  function trocarHash(alvoHash) {
    var fr0 = document.getElementById('promov-agenda-frame');
    if (!fr0) return;
    try { fr0.contentWindow.location.hash = alvoHash; } catch (e) { fr0.src = DASH + '?v=' + Date.now() + alvoHash; }
  }
  function mostrarBarraTelefone(candidatos) {
    var p = document.getElementById('promov-agenda-painel'); if (!p) return;
    var barra = document.getElementById('promov-barra-tel');
    if (!barra) {
      barra = document.createElement('div'); barra.id = 'promov-barra-tel';
      barra.style.cssText = 'display:flex;align-items:center;gap:8px;flex-wrap:wrap;padding:7px 12px;background:#1b1f27;border-top:1px solid rgba(255,255,255,.08);color:#dfe3ee;font-family:sans-serif;font-size:12px;';
      p.insertBefore(barra, document.getElementById('promov-agenda-frame'));
    }
    barra.innerHTML = '';
    var txt = document.createElement('span'); txt.textContent = '📞 Não achei o telefone desta conversa. Cole aqui ou escolha:'; txt.style.color = '#ffd166';
    barra.appendChild(txt);
    var inp = document.createElement('input'); inp.placeholder = '(62) 99999-9999';
    inp.style.cssText = 'background:#0c0e12;border:1px solid rgba(255,255,255,.18);color:#fff;border-radius:8px;padding:5px 8px;font-size:12px;width:150px;';
    var ok = document.createElement('div'); ok.textContent = '📅 Marcar'; ok.setAttribute('data-botao', '1');
    ok.style.cssText = 'cursor:pointer;padding:5px 10px;border-radius:8px;background:rgba(255,209,102,.16);border:1px solid rgba(255,209,102,.5);color:#ffd166;font-weight:700;';
    function usar() {
      var d = digitos(inp.value);
      if (!telValido(d)) { inp.style.borderColor = '#ff6b6b'; inp.focus(); return; }
      barra.remove(); abrirPainelAgenda(d, 'marcar', '');
    }
    ok.onclick = usar; inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') usar(); });
    barra.appendChild(inp); barra.appendChild(ok);
    (candidatos || []).slice(0, 8).forEach(function (d) {
      var chip = document.createElement('div'); chip.textContent = '📱 ' + bonito(d); chip.setAttribute('data-botao', '1');
      chip.style.cssText = 'cursor:pointer;padding:4px 9px;border-radius:999px;border:1px solid rgba(110,168,255,.5);color:#6ea8ff;font-weight:700;';
      chip.onclick = function () { barra.remove(); abrirPainelAgenda(d, 'marcar', nomeDaTela(d)); };
      barra.appendChild(chip);
    });
    var x = document.createElement('div'); x.textContent = '✕'; x.setAttribute('data-botao', '1');
    x.style.cssText = 'cursor:pointer;padding:4px 8px;color:#9aa3b2;margin-left:auto;'; x.onclick = function () { barra.remove(); };
    barra.appendChild(x);
    setTimeout(function () { try { inp.focus(); } catch (e) {} }, 50);
  }
  function abrirPainelAgenda(tel, modo, nome) {   // nome mantido: o cartão do lead chama esta função
    var p = document.getElementById('promov-agenda-painel');
    var m = modo === 'marcar' ? 'marcar' : modo === 'agenda' ? 'agenda' : (modo === 'lead' || tel ? 'ficha' : '');
    var alvoHash = hashDe(tel, m, nome);
    if (p) {
      p.style.display = 'flex';
      var bT = document.getElementById('promov-barra-tel'); if (bT && m !== 'agenda') bT.remove();
      trocarHash(alvoHash);
      return;
    }
    p = document.createElement('div');
    p.id = 'promov-agenda-painel';
    var tam = tamGuardado(), pos = lembrar('promovPainelPos'), tl = tela();
    var w = tam && tam.w ? Math.min(tam.w, tl.w) : Math.round(tl.w * 0.66);
    var h = tam && tam.h ? Math.min(tam.h, tl.h) : tl.h;
    var left = Math.max(0, tl.w - w), top = 0;
    if (pos && pos.left) { left = Math.min(Math.max(0, parseInt(pos.left, 10) || 0), tl.w - 80); top = Math.min(Math.max(0, parseInt(pos.top, 10) || 0), tl.h - 60); }
    p.style.cssText = 'position:fixed;top:' + top + 'px;left:' + left + 'px;width:' + w + 'px;height:' + h + 'px;min-width:360px;min-height:280px;max-width:100vw;max-height:100vh;'
      + 'overflow:visible;z-index:2147483646;background:#0c0e12;border:2px solid rgba(246,163,80,.7);border-radius:12px;box-shadow:0 12px 40px rgba(0,0,0,.55);display:flex;flex-direction:column;';
    var topo = document.createElement('div');
    topo.title = 'Segure e arraste para mover a janela · as bordas e os cantos mudam o tamanho';
    topo.style.cssText = 'display:flex;align-items:center;gap:6px;padding:7px 10px;background:#14171d;color:#fff;font-family:sans-serif;font-size:12px;user-select:none;flex-wrap:wrap;cursor:move;border-radius:10px 10px 0 0;';
    function botao(txt, dica, acao, cor) {
      var b = document.createElement('div'); b.textContent = txt; b.title = dica; b.setAttribute('data-botao', '1');
      b.style.cssText = 'cursor:pointer;padding:5px 9px;border-radius:9px;border:1px solid rgba(255,255,255,.14);color:' + (cor || '#dfe3ee') + ';font-weight:700;font-size:11.5px;white-space:nowrap;';
      b.onmouseover = function () { b.style.background = 'rgba(255,255,255,.08)'; }; b.onmouseout = function () { b.style.background = ''; };
      b.onclick = function (ev) { ev.stopPropagation(); acao(); }; return b;
    }
    var tt = document.createElement('b'); tt.innerHTML = '📊 Dash Promov <span style="font-weight:400;color:#8b93a5;font-size:10.5px;">ext ' + VERSAO_EXT + '</span>'; tt.style.cssText = 'flex:1;font-size:13px;color:#f6a350;white-space:nowrap;';
    topo.appendChild(tt);
    topo.appendChild(botao('📅 marcar reunião', 'Lê o telefone da conversa aberta e abre a agenda já marcando para essa pessoa', marcar, '#ffd166'));
    topo.appendChild(botao('🔎 este contato', 'Abre no dash a ficha da pessoa desta conversa', function () {
      var ld = leadDaTela(); if (!ld.tel) { mostrarBarraTelefone(ld.candidatos); return; }
      abrirPainelAgenda(ld.tel, 'lead');
    }, '#6ea8ff'));
    topo.appendChild(botao('📆 agenda', 'Abre a agenda do dash', function () { abrirPainelAgenda('', 'agenda'); }));
    topo.appendChild(botao('🏠 início', 'Tela inicial do dash', function () { abrirPainelAgenda('', ''); }));
    topo.appendChild(botao('A−', 'Diminui o tamanho do conteúdo', function () { mudarZoom(-1); }));
    topo.appendChild(botao('A+', 'Aumenta o tamanho do conteúdo', function () { mudarZoom(1); }));
    topo.appendChild(botao('⟷', 'Alterna: metade, dois terços ou a tela toda (as bordas também redimensionam)', function () {
      var i = (LARGURAS.indexOf(larguraAtual()) + 1) % LARGURAS.length;
      try { localStorage.setItem('promovDashLarg', LARGURAS[i]); } catch (e) {}
      var fr = parseFloat(LARGURAS[i]) / 100;
      var nw = Math.round(window.innerWidth * fr);
      p.style.width = nw + 'px'; p.style.height = window.innerHeight + 'px'; p.style.top = '0px'; p.style.left = Math.max(0, window.innerWidth - nw) + 'px';
      guardarTam(p);
    }));
    topo.appendChild(botao('↗ aba', 'Abre o dash numa aba própria', function () {
      var url = DASH + '?v=' + Date.now();
      try { chrome.runtime.sendMessage({ acao: 'abrirDash', url: url }); } catch (e) { window.open(url, 'promov_dash'); }
    }));
    topo.appendChild(botao('✕', 'Fecha a janela (o dash continua carregado)', function () { p.style.display = 'none'; }, '#9aa3b2'));
    var fr = document.createElement('iframe');
    fr.id = 'promov-agenda-frame';
    fr.src = DASH + '?v=' + Date.now() + alvoHash;   // sempre a versão mais nova do dash
    fr.style.cssText = 'flex:1;border:0;width:100%;background:#0c0e12;border-radius:0 0 10px 10px;min-height:0;';
    fr.setAttribute('allow', 'clipboard-write');
    p.appendChild(topo); p.appendChild(fr);
    document.body.appendChild(p);
    arrastavel(p, topo, 'promovPainelPos');   // arrasta pelo topo; a posição fica guardada
    redimensionavel(p, function () { guardarTam(p); });
    window.addEventListener('resize', function () {   // a janela do navegador mudou: mantém o painel dentro dela
      var r = p.getBoundingClientRect();
      if (r.right > window.innerWidth) p.style.left = Math.max(0, window.innerWidth - r.width) + 'px';
      if (r.bottom > window.innerHeight) p.style.top = Math.max(0, window.innerHeight - r.height) + 'px';
    });
  }
  function mudarZoom(passo) {
    var z = zoomAtual(), i = ZOOMS.indexOf(z); if (i < 0) i = 3;
    i = Math.min(ZOOMS.length - 1, Math.max(0, i + passo));
    guardar('promovDashZoom', ZOOMS[i]);
    trocarHash('#clint=1&zoom=' + ZOOMS[i] + '&t=' + Date.now());   // o dash só troca o tamanho, sem sair da tela
  }
  function alternarPainelAgenda() {
    var p = document.getElementById('promov-agenda-painel');
    if (p && p.style.display !== 'none') { p.style.display = 'none'; return; }   // clicou de novo = fecha
    // Bruno 08/09/2026: abre DIRETO no "marcar reunião" da pessoa da conversa aberta (não na tela inicial)
    var ld = leadDaTela();
    if (ld.tel) { abrirPainelAgenda(ld.tel, 'marcar', ld.nome); return; }
    abrirPainelAgenda('', 'agenda');
    mostrarBarraTelefone(ld.candidatos);
  }

  var btnAg = document.createElement('div');
  btnAg.id = 'promov-agenda-btn';
  btnAg.textContent = '📊 Dash';
  btnAg.title = 'Um clique abre a agenda já marcando reunião para a pessoa desta conversa; outro clique fecha. Segure e arraste para mudar o botão de lugar.';
  btnAg.style.cssText = 'position:fixed;right:22px;bottom:22px;z-index:2147483647;background:#14171d;color:#f6a350;border:1px solid rgba(246,163,80,.6);font-family:sans-serif;font-size:13px;font-weight:800;padding:10px 14px;border-radius:999px;cursor:pointer;box-shadow:0 6px 24px rgba(0,0,0,.45);user-select:none;';
  btnAg.onclick = function () { if (btnAg._arrastou) { btnAg._arrastou = false; return; } alternarPainelAgenda(); };
  document.body.appendChild(btnAg);
  arrastavel(btnAg, btnAg, 'promovBtnAgendaPos');

  var btn = btnAg;   // referencia mantida: o cartao do lead se apoia no botao

  // ===== reconhece o LEAD da conversa aberta e mostra os dados dele =====
  var PLANILHA_CSV = 'https://docs.google.com/spreadsheets/d/1xJykoW0UHr5hA-ELo5nV8uBkYykRG6OQdmMvDlUnhVg/export?format=csv&gid=2012456321';
  var _robo = null, _roboEm = 0, _csv = null, _csvEm = 0, _leadInfo = {}, _telAtual = '';

  function acharRobo(cb) {   // o endereço do robô muda a cada implantação: lê do próprio dash publicado
    if (_robo && Date.now() - _roboEm < 3600000) return cb(_robo);
    fetch(DASH + 'index.html?t=' + Date.now()).then(function (r) { return r.text(); }).then(function (t) {
      var m = t.match(/https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec/);
      if (m) { _robo = m[0]; _roboEm = Date.now(); }
      cb(_robo);
    }).catch(function () { cb(_robo); });
  }
  function lerCSV(txt) {   // separa respeitando aspas (nomes com vírgula)
    var linhas = [], linha = [], campo = '', dentro = false;
    for (var i = 0; i < txt.length; i++) {
      var ch = txt[i];
      if (dentro) {
        if (ch === '"') { if (txt[i + 1] === '"') { campo += '"'; i++; } else dentro = false; }
        else campo += ch;
      } else if (ch === '"') dentro = true;
      else if (ch === ',') { linha.push(campo); campo = ''; }
      else if (ch === '\n') { linha.push(campo); linhas.push(linha); linha = []; campo = ''; }
      else if (ch !== '\r') campo += ch;
    }
    if (campo || linha.length) { linha.push(campo); linhas.push(linha); }
    return linhas;
  }
  function reunioesDoTel(d, cb) {   // planilha de reuniões (pública para leitura)
    function usa() {
      var head = _csv[0].map(function (h) { return String(h).toLowerCase(); });
      var iN = head.indexOf('nome'), iT = head.indexOf('telefone'), iS = head.indexOf('status'), iD = head.indexOf('data');
      var t8 = d.slice(-8), achou = null;
      for (var i = 1; i < _csv.length; i++) {
        var r = _csv[i];
        if (String(r[iT] || '').replace(/\D/g, '').slice(-8) !== t8) continue;
        achou = { nome: r[iN] || '', status: r[iS] || '', data: r[iD] || '' };   // fica a mais recente (de cima para baixo)
      }
      cb(achou);
    }
    if (_csv && Date.now() - _csvEm < 180000) return usa();
    fetch(PLANILHA_CSV + '&t=' + Date.now()).then(function (r) { return r.text(); }).then(function (t) {
      _csv = lerCSV(t); _csvEm = Date.now(); usa();
    }).catch(function () { cb(null); });
  }
  function cadastroClint(d, cb) {   // nome/etapa/dona pelo robô do dash
    acharRobo(function (robo) {
      if (!robo) return cb(null);
      fetch(robo + '?callback=cb&payload=' + encodeURIComponent(JSON.stringify({ action: 'clintLead', telefone: d })))
        .then(function (r) { return r.text(); })
        .then(function (t) { cb(JSON.parse(t.replace(/^cb\(/, '').replace(/\)$/, ''))); })
        .catch(function () { cb(null); });
    });
  }
  function mostrarCartao(d, reuniao, clint) {
    var card = document.getElementById('promov-lead-card');
    if (!card) { card = document.createElement('div'); card.id = 'promov-lead-card'; document.body.appendChild(card); }
    var nome = (reuniao && reuniao.nome) || (clint && clint.nomeClint) || nomeDaTela(d) || '';
    var linhas = [];
    linhas.push('<b style="color:#f6a350;">👤 ' + (nome || bonito(d)) + '</b>');
    card._tel = d; card._nome = nome;
    if (reuniao) linhas.push('📇 ' + (reuniao.status || 'reunião') + (reuniao.data ? ' · ' + reuniao.data : ''));
    else linhas.push('🆕 sem reunião registrada');
    if (clint && clint.achou) linhas.push('🟣 ' + [clint.etapaClint || '', clint.dono ? '✋ ' + clint.dono : ''].filter(Boolean).join(' · '));
    var r = btn.getBoundingClientRect();
    linhas.push('<span style="color:#ffd166;font-weight:700;">📅 clique para marcar reunião</span> <span style="color:#6ea8ff;">· 🔎 ver ficha</span>');
    card.innerHTML = linhas.join('<br>');
    card.style.cssText = 'position:fixed;left:' + Math.max(6, r.left - 40) + 'px;top:' + Math.max(6, r.top - 104) + 'px;z-index:2147483647;background:#14171d;color:#dfe3ee;border:1px solid rgba(246,163,80,.5);border-radius:12px;padding:9px 13px;font-family:sans-serif;font-size:12px;line-height:1.5;box-shadow:0 10px 26px rgba(0,0,0,.45);max-width:280px;cursor:pointer;';
    card.onclick = function (ev) {
      if (!card._tel) return;
      var t = (ev.target && ev.target.textContent) || '';
      if (t.indexOf('ver ficha') !== -1) abrirPainelAgenda(card._tel, 'lead'); else abrirPainelAgenda(card._tel, 'marcar', card._nome);
    };
  }
  function esconderCartao() {
    var card = document.getElementById('promov-lead-card');
    if (card) card.remove();
  }
  function vigiarLead() {
    if (!estaNoAtendimento()) { _telAtual = ''; esconderCartao(); return; }
    var ld = leadDaTela();
    var d = ld.tel;
    if (d === _telAtual) return;
    _telAtual = d;
    if (!d) { esconderCartao(); return; }
    if (_leadInfo[d]) { mostrarCartao(d, _leadInfo[d].reuniao, _leadInfo[d].clint); return; }
    reunioesDoTel(d, function (reuniao) {
      cadastroClint(d, function (clint) {
        _leadInfo[d] = { reuniao: reuniao, clint: clint };
        if (_telAtual === d) mostrarCartao(d, reuniao, clint);
      });
    });
  }

  // ===== o cartão do lead aparece nas telas de CONVERSA (a Clint troca de tela sem recarregar) =====
  function estaNoAtendimento() { return /chat|inbox|atendimento|conversa|whatsapp|mensage/i.test(location.pathname + location.search); }
  function ajustaVisibilidade() {
    // o botão do dash fica em TODA a Clint (Bruno 08/09/2026); o cartão do lead só na conversa
    if (!estaNoAtendimento()) fecharEscolha();
    try { vigiarLead(); } catch (e) {}
  }
  ajustaVisibilidade();
  setInterval(ajustaVisibilidade, 1200);
})();
